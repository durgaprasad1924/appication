<?php
require 'vendor/autoload.php'; // AWS SDK for PHP

use Aws\S3\S3Client;
use Aws\DynamoDb\DynamoDbClient;

// ---------------------------
// RDS (MySQL) Connection
// ---------------------------
$rds_host = 'database-1.chw6ayk4u47m.ap-south-1.rds.amazonaws.com';
$rds_dbname = 'mydb';
$rds_username = 'admin';
$rds_password = '12345678';

try {
    $pdo = new PDO(
        "mysql:host=$rds_host;dbname=$rds_dbname;charset=utf8mb4",
        $rds_username,
        $rds_password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    die("❌ RDS Connection Failed: " . htmlspecialchars($e->getMessage()));
}

// ---------------------------
// S3 Client Initialization
// ---------------------------
$s3 = new S3Client([
    'region'  => 'ap-south-1', // your regio
    'version' => 'latest',
]);

$s3_bucket = 'my-house-data123';

// ---------------------------
// DynamoDB Client Initialization
// ---------------------------
$dynamodb = new DynamoDbClient([
    'region'  => 'ap-south-1',
    'version' => 'latest',
]);

$ddb_table = 'UserImages';
?>
