<?php
session_start();
include 'database.php'; // Ensure $pdo is defined inside this file

// Ensure only owners can access this page
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'owner') {
    header("Location: login.html");
    exit();
}

$owner_id = $_SESSION['user_id'];

// Handle property withdrawal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['withdraw_property_id'])) {
    $property_id = intval($_POST['withdraw_property_id']); // Ensure integer input
    
    // Fetch property price and images
    $stmt = $pdo->prepare("SELECT price, images FROM properties WHERE id = ? AND owner_id = ?");
    $stmt->execute([$property_id, $owner_id]);
    $property = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($property) {
        $refund_amount = $property['price'] * 0.75; // Calculate 75% refund

        // Delete property images from the server
        $image_paths = explode(',', $property['images']);
        foreach ($image_paths as $image) {
            if (file_exists($image)) {
                unlink($image); // Delete image
            }
        }

        // Delete property from database
        $stmt = $pdo->prepare("DELETE FROM properties WHERE id = ? AND owner_id = ?");
        $stmt->execute([$property_id, $owner_id]);

        echo "<script>alert('✅ Property withdrawn. Refund Amount: ₹$refund_amount'); window.location.href='owner_dashboard.php';</script>";
    } else {
        echo "<script>alert('⚠️ Error: Property not found.'); window.location.href='owner_dashboard.php';</script>";
    }
}

// Fetch properties added by owner
$stmt = $pdo->prepare("SELECT * FROM properties WHERE owner_id = ?");
$stmt->execute([$owner_id]);
$properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Owner Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Owner Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="add_property.php">Add Property</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h2>Your Properties</h2>
    <div class="row">
        <?php foreach ($properties as $property): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <?php
                    $image_paths = explode(',', $property['images']);
                    $first_image = !empty($image_paths[0]) ? htmlspecialchars($image_paths[0]) : 'default.jpg';
                    ?>
                    <img src="<?= $first_image; ?>" class="card-img-top" alt="<?= htmlspecialchars($property['title']); ?>" style="height:200px; object-fit:cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($property['title']); ?></h5>
                        <p><strong>Views:</strong> <?= htmlspecialchars($property['views']); ?></p>
                        <p><?= htmlspecialchars($property['description']); ?></p>
                        <div class="d-flex justify-content-between">
                            <a href="edit_property.php?id=<?= $property['id']; ?>" class="btn btn-warning">Edit</a>
                            <form method="POST" onsubmit="return confirm('Are you sure you want to withdraw this property?');">
                                <input type="hidden" name="withdraw_property_id" value="<?= $property['id']; ?>">
                                <button type="submit" class="btn btn-danger">Withdraw</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
