<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Collect and sanitize input
        $fname = trim($_POST['fname']);
        $lname = trim($_POST['lname']);
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirmPassword'];
        $userType = $_POST['userType'];
        $country = $_POST['country'];
        $state = $_POST['state'];

        // Validate required fields
        if (empty($fname) || empty($lname) || empty($username) || empty($email) || empty($phone) || empty($password) || empty($userType) || empty($country) || empty($state)) {
            echo json_encode(["status" => "error", "message" => "All fields are required."]);
            exit();
        }

        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(["status" => "error", "message" => "Invalid email format."]);
            exit();
        }

        // Validate phone number (10 digits)
        if (!preg_match("/^[0-9]{10}$/", $phone)) {
            echo json_encode(["status" => "error", "message" => "Phone number must be 10 digits."]);
            exit();
        }

        // Validate password (Minimum 6 characters, at least one number & special character)
        if (!preg_match("/^(?=.*[0-9])(?=.*[\W_]).{6,}$/", $password)) {
            echo json_encode(["status" => "error", "message" => "Password must be at least 6 characters long and contain one number & one special character."]);
            exit();
        }

        // Check if passwords match
        if ($password !== $confirmPassword) {
            echo json_encode(["status" => "error", "message" => "Passwords do not match."]);
            exit();
        }

        // Check if email or username already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$email, $username]);
        if ($stmt->fetch()) {
            echo json_encode(["status" => "error", "message" => "Email or Username already exists."]);
            exit();
        }

        // Hash the password securely
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Handle file uploads (Aadhar/Passport)
        $uploadDir = "uploads/";
        $aadharFilePath = null;
        $passportFilePath = null;
        
        if ($country == "India" && isset($_FILES["aadhar"]["name"]) && $_FILES["aadhar"]["size"] > 0) {
            $aadharFilePath = $uploadDir . "Aadhar_" . time() . "_" . basename($_FILES["aadhar"]["name"]);
            move_uploaded_file($_FILES["aadhar"]["tmp_name"], $aadharFilePath);
        } elseif ($country != "India" && isset($_FILES["passport"]["name"]) && $_FILES["passport"]["size"] > 0) {
            $passportFilePath = $uploadDir . "Passport_" . time() . "_" . basename($_FILES["passport"]["name"]);
            move_uploaded_file($_FILES["passport"]["tmp_name"], $passportFilePath);
        }

        // Insert user into the database
        $stmt = $pdo->prepare("INSERT INTO users (fname, lname, username, email, phone, password, user_type, country, state, aadhar, passport) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$fname, $lname, $username, $email, $phone, $hashedPassword, $userType, $country, $state, $aadharFilePath, $passportFilePath])) {
            echo json_encode([
                "status" => "success",
                "message" => "Registration successful! Redirecting...",
                "redirect" => "login.php"
            ]);
            exit();
            
            exit();
        } else {
            echo json_encode(["status" => "error", "message" => "Registration failed."]);
            exit();
        }
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Database Error: " . $e->getMessage()]);
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Real Estate Portal</title>
    <link rel="stylesheet" href="styles.css">
</head>
<style>
        body {
            background-image: url('background.jpg');
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif;
            color: white;
        }
        .container {
            width: 40%;
            margin: auto;
            background: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 10px;
        }
        .nav-bar {
            background-color: #333;
            padding: 15px;
            text-align: center;
            font-size: 20px;
            color: white;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
            border: none;
        }
        button {
            background-color: blue;
            color: white;
            cursor: pointer;
        }
        button:hover {
            background-color: darkblue;
        }
    </style>
    
    <nav style="background-color: #333; padding: 15px;">
    <div class="nav-bar">Register</div>
    <a href="index.php" style="color: white; margin-right: 20px; text-decoration: none;">Home</a>
    <a href="about.php" style="color: white; margin-right: 20px; text-decoration: none;">About</a>
    <a href="contact.php" style="color: white; text-decoration: none;">Contact</a>
</nav>

    <section class="container">
        <h2>Create an Account</h2>
        <form action="submit_registration.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
            
            <div class="form-group">
                <label for="userType">Select User Type:</label>
                <select id="userType" name="userType" onchange="showAdditionalFields()" required>
                    <option value="customer">Customer</option>
                    <option value="tenant">Tenant</option>
                    <option value="owner">Owner</option>
                </select>
            </div>

            <div class="form-group">
                <label for="fname">First Name:</label>
                <input type="text" id="fname" name="fname" placeholder="First Name" required>
            </div>

            <div class="form-group">
                <label for="lname">Last Name:</label>
                <input type="text" id="lname" name="lname" placeholder="Last Name" required>
            </div>

            <div class="form-group">
                <label for="username">Username (Unique):</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="form-group">
                <label for="confirmPassword">Confirm Password:</label>
                <input type="password" id="confirmPassword" name="confirmPassword" required>
            </div>

            <div class="form-group">
                <label for="country">Country:</label>
                <select id="country" name="country" onchange="checkCountry()" required>
                    <option value="India" selected>India</option>
                    <option value="USA">USA</option>
                    <option value="UK">UK</option>
                    <option value="Canada">Canada</option>
                    <option value="Australia">Australia</option>
                    <option value="Germany">Germany</option>
                    <option value="France">France</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="form-group" id="passportField" style="display: none;">
                <label for="passport">Upload Passport (for non-Indian residents):</label>
                <input type="file" id="passport" name="passport" accept=".pdf, .jpg, .png">
            </div>

            <div class="form-group" id="aadharField">
                <label for="aadhar">Upload Aadhar Card:</label>
                <input type="file" id="aadhar" name="aadhar" accept=".pdf, .jpg, .png" required>
            </div>
            <div class="form-group">
                <label for="state">State:</label>
                <select id="state" name="state" required>
                    <option value="" disabled selected>Select State</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                    <option value="Assam">Assam</option>
                    <option value="Bihar">Bihar</option>
                    <option value="Chhattisgarh">Chhattisgarh</option>
                    <option value="Goa">Goa</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Manipur">Manipur</option>
                    <option value="Meghalaya">Meghalaya</option>
                    <option value="Mizoram">Mizoram</option>
                    <option value="Nagaland">Nagaland</option>
                    <option value="Odisha">Odisha</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Rajasthan">Rajasthan</option>
                    <option value="Sikkim">Sikkim</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Telangana">Telangana</option>
                    <option value="Tripura">Tripura</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="Uttarakhand">Uttarakhand</option>
                    <option value="West Bengal">West Bengal</option>
                </select>
            </div>

            <!-- Owner-Specific Fields -->
            <div id="ownerFields" style="display: none;">
                <div class="form-group">
                    <label for="gstId">GST ID (for Owners):</label>
                    <input type="text" id="gstId" name="gstId">
                </div>
                
                <div class="form-group">
                    <label for="taxPayment">Upload Recent Tax Payment Slips:</label>
                    <input type="file" id="taxPayment" name="taxPayment" accept=".pdf, .jpg, .png">
                </div>
            </div>

            <button type="submit">Register</button>
            <p>Already registered? <a href="login.php">Login here</a></p>
        </form>
    </section>
</body>
</html>
