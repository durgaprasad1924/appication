<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'database.php';

// Helper to clean input
function cleanInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect fields
    $userType = cleanInput($_POST['userType']);
    $fname = cleanInput($_POST['fname']);
    $lname = cleanInput($_POST['lname']);
    $username = cleanInput($_POST['username']);
    $email = cleanInput($_POST['email']);
    $phone = cleanInput($_POST['phone']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $country = cleanInput($_POST['country']);
    $state = cleanInput($_POST['state']);

    // File upload vars
    $aadharPath = null;
    $passportPath = null;

    // 1️⃣ Validations
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["status" => "error", "message" => "Invalid email."]);
        exit();
    }

    if (!preg_match("/^[6-9]\d{9}$/", $phone)) {
        echo json_encode(["status" => "error", "message" => "Invalid phone number."]);
        exit();
    }

    if (strlen($password) < 8 || !preg_match('/\d/', $password) || !preg_match('/[@$!%*?&]/', $password)) {
        echo json_encode(["status" => "error", "message" => "Weak password."]);
        exit();
    }

    if ($password !== $confirmPassword) {
        echo json_encode(["status" => "error", "message" => "Passwords do not match."]);
        exit();
    }

    // 2️⃣ Check existing user
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(["status" => "error", "message" => "Username or Email already exists."]);
        exit();
    }

    // 3️⃣ Upload file to S3
    $uploadKey = null;

    if ($country === "India" && isset($_FILES['aadhar']) && $_FILES['aadhar']['size'] > 0) {
        $uploadKey = "aadhar_" . time() . "_" . basename($_FILES['aadhar']['name']);
        $filePath = $_FILES['aadhar']['tmp_name'];

        try {
            $result = $s3->putObject([
                'Bucket' => $s3_bucket,
                'Key' => $uploadKey,
                'SourceFile' => $filePath,
                'ACL' => 'public-read',
            ]);
            $aadharPath = $result['ObjectURL'];
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => "S3 Upload failed: " . $e->getMessage()]);
            exit();
        }
    } elseif ($country !== "India" && isset($_FILES['passport']) && $_FILES['passport']['size'] > 0) {
        $uploadKey = "passport_" . time() . "_" . basename($_FILES['passport']['name']);
        $filePath = $_FILES['passport']['tmp_name'];

        try {
            $result = $s3->putObject([
                'Bucket' => $s3_bucket,
                'Key' => $uploadKey,
                'SourceFile' => $filePath,
                'ACL' => 'public-read',
            ]);
            $passportPath = $result['ObjectURL'];
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => "S3 Upload failed: " . $e->getMessage()]);
            exit();
        }
    }

    // 4️⃣ Insert user into RDS
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("INSERT INTO users (user_type, fname, lname, username, email, phone, password, country, state, aadhar, passport)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $userType, $fname, $lname, $username, $email, $phone, $hashedPassword,
        $country, $state, $aadharPath, $passportPath
    ]);

    $userId = $pdo->lastInsertId();

    // 5️⃣ Save metadata to DynamoDB
    try {
        $dynamodb->putItem([
            'TableName' => $ddb_table,
            'Item' => [
                'user_id'   => ['N' => (string)$userId],
                'email'     => ['S' => $email],
                's3_file'   => ['S' => $aadharPath ?? $passportPath ?? ''],
                'uploaded'  => ['S' => date('c')],
                'country'   => ['S' => $country],
            ]
        ]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => "DynamoDB Error: " . $e->getMessage()]);
        exit();
    }

    echo json_encode(["status" => "success", "message" => "Registration complete!", "redirect" => "login.php"]);
    exit();
}

echo json_encode(["status" => "error", "message" => "Invalid request."]);
exit();
?>

