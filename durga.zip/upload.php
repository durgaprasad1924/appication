$rds_host = 'database-1.chw6ayk4u47m.ap-south-1.rds.amazonaws.com';   // ✅ your actual RDS endpoint
$rds_dbname = 'mydb';                            // ✅ your DB name
$rds_username = 'admin';                             // ✅ your RDS username
$rds_password = '12345678';                          // ✅ your RDS password

$s3_bucket = 'my-house-data123';                            // ✅ your actual S3 bucket name
$ddb_table = 'UserImages';                 // ✅ your DynamoDB table name
<?php
require 'vendor/autoload.php'; // AWS SDK for PHP

use Aws\S3\S3Client;
use Aws\DynamoDb\DynamoDbClient;

// ---------------------------
// RDS (MySQL) Connection
// ---------------------------
$rds_host = 'database-1.chw6ayk4u47m.ap-south-1.rds.amazonaws.com';
$rds_dbname = 'mydb';
$rds_username = 'admin';
$rds_password = '12345678';

try {
    $pdo = new PDO(
        "mysql:host=$rds_host;dbname=$rds_dbname;charset=utf8mb4",
        $rds_username,
        $rds_password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    die("❌ RDS Connection Failed: " . htmlspecialchars($e->getMessage()));
}

// ---------------------------
// AWS Setup (S3 + DynamoDB)
// ---------------------------
$aws_region = 'ap-south-1';
$s3_bucket = 'my-house-data123';
$ddb_table = 'UserImages';

// If you're using EC2 IAM Role, you can skip credentials block
$s3 = new S3Client([
    'region'  => $aws_region,
    'version' => 'latest',
]);

$dynamodb = new DynamoDbClient([
    'region'  => $aws_region,
    'version' => 'latest',
]);

// ---------------------------
// Handle Image Upload
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $file = $_FILES['image'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        die('❌ Upload failed with error code: ' . $file['error']);
    }

    $imageKey = uniqid('house_', true) . '_' . basename($file['name']);
    $tempFile = $file['tmp_name'];

    // 1. Upload to S3
    try {
        $result = $s3->putObject([
            'Bucket' => $s3_bucket,
            'Key'    => $imageKey,
            'SourceFile' => $tempFile,
            'ACL'    => 'public-read'
        ]);
        $imageUrl = $result['ObjectURL'];
    } catch (Exception $e) {
        die('❌ S3 Upload Failed: ' . $e->getMessage());
    }

    // 2. Insert into MySQL (RDS)
    try {
        $stmt = $pdo->prepare("INSERT INTO houses (image_url) VALUES (:url)");
        $stmt->execute(['url' => $imageUrl]);
        $houseId = $pdo->lastInsertId();
    } catch (PDOException $e) {
        die('❌ RDS Insert Failed: ' . $e->getMessage());
    }

    // 3. Insert Metadata into DynamoDB
    try {
        $dynamodb->putItem([
            'TableName' => $ddb_table,
            'Item' => [
                'image_id'   => ['S' => uniqid()],
                'house_id'   => ['N' => (string)$houseId],
                'image_url'  => ['S' => $imageUrl],
                'upload_time'=> ['S' => date('c')],
                'file_type'  => ['S' => mime_content_type($tempFile)],
                'file_size'  => ['N' => (string)$file['size']],
            ]
        ]);
    } catch (Exception $e) {
        die('❌ DynamoDB Insert Failed: ' . $e->getMessage());
    }

    echo "✅ Upload successful!<br>S3 URL: <a href='$imageUrl' target='_blank'>$imageUrl</a>";
} else {
    echo "Please upload a file using the form.";
}
?>

