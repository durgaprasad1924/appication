<footer>
    <p>&copy; <?php echo date("Y"); ?> Real Estate Portal. All rights reserved.</p>
</footer>

</body>
</html>
