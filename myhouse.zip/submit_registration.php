<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Required fields
    $requiredFields = ['userType', 'fname', 'lname', 'username', 'email', 'phone', 'password', 'confirmPassword', 'country', 'state'];

    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(["status" => "error", "message" => ucfirst($field) . " is required."]);
            exit();
        }
    }

    // Function to sanitize input
    function cleanInput($data) {
        return htmlspecialchars(strip_tags(trim($data)));
    }

    // Collect & sanitize input data
    $userType = cleanInput($_POST['userType']);
    $fname = cleanInput($_POST['fname']);
    $lname = cleanInput($_POST['lname']);
    $username = cleanInput($_POST['username']);
    $email = cleanInput($_POST['email']);
    $phone = cleanInput($_POST['phone']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $country = cleanInput($_POST['country']);
    $state = cleanInput($_POST['state']);
    $gstId = isset($_POST['gstId']) ? cleanInput($_POST['gstId']) : null;

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["status" => "error", "message" => "Invalid email format."]);
        exit();
    }

    // Validate phone number (Indian format: Starts with 6-9 and has 10 digits)
    if (!preg_match("/^[6-9]\d{9}$/", $phone)) {
        echo json_encode(["status" => "error", "message" => "Invalid phone number."]);
        exit();
    }

    // Validate password (Min 8 characters, at least 1 number & special character)
    if (strlen($password) < 8 || !preg_match('/\d/', $password) || !preg_match('/[@$!%*?&]/', $password)) {
        echo json_encode(["status" => "error", "message" => "Password must be at least 8 characters long, contain a number & a special character."]);
        exit();
    }

    // Confirm password check
    if ($password !== $confirmPassword) {
        echo json_encode(["status" => "error", "message" => "Passwords do not match."]);
        exit();
    }

    // Hash the password securely
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    try {
        // Check if username or email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "error", "message" => "Username or Email already exists."]);
            exit();
        }

        // Insert user into the database
        $stmt = $pdo->prepare("INSERT INTO users (user_type, fname, lname, username, email, phone, password, country, state, gst_id) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$userType, $fname, $lname, $username, $email, $phone, $hashedPassword, $country, $state, $gstId]);

        echo json_encode(["status" => "success", "message" => "Registration successful! Redirecting..."]);
        exit();
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Database Error: " . $e->getMessage()]);
        exit();
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request."]);
    exit();
}
?>
