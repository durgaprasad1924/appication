<?php
session_start();
require 'database.php';

// Fetch available properties
$stmt = $pdo->prepare("SELECT * FROM properties WHERE status = 'active'");
$stmt->execute();
$properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Properties - Real Estate Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&callback=initMap" async defer></script>
    <script>
        function initMap() {
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 5,
                center: { lat: 20.5937, lng: 78.9629 }
            });
            
            var propertyIcons = {
                'flat': 'flat-icon.png',
                'house': 'house-icon.png',
                'land': 'land-icon.png',
                'agriculture': 'agriculture-icon.png'
            };
            
            var properties = <?php echo json_encode($properties); ?>;
            properties.forEach(property => {
                if (property.latitude && property.longitude) {
                    var marker = new google.maps.Marker({
                        position: { lat: parseFloat(property.latitude), lng: parseFloat(property.longitude) },
                        map: map,
                        title: property.details,
                        icon: propertyIcons[property.property_type] || 'default-icon.png'
                    });

                    var infoWindow = new google.maps.InfoWindow({
                        content: `<h5>${property.details}</h5><p>Price: ₹${property.price}</p><a href='property_details.php?id=${property.id}'>View Details</a>`
                    });

                    marker.addListener('click', function () {
                        infoWindow.open(map, marker);
                    });
                }
            });
        }
        
        function filterProperties() {
            var type = document.getElementById("propertyType").value.toLowerCase();
            var location = document.getElementById("location").value.toLowerCase();
            var minPrice = parseInt(document.getElementById("minPrice").value) || 0;
            var maxPrice = parseInt(document.getElementById("maxPrice").value) || Infinity;
            var properties = document.querySelectorAll(".property-item");

            properties.forEach(property => {
                var propType = property.getAttribute("data-type").toLowerCase();
                var propLocation = property.getAttribute("data-location").toLowerCase();
                var propPrice = parseInt(property.getAttribute("data-price"));

                if ((type === "all" || propType.includes(type)) &&
                    (location === "" || propLocation.includes(location)) &&
                    (propPrice >= minPrice && propPrice <= maxPrice)) {
                    property.style.display = "block";
                } else {
                    property.style.display = "none";
                }
            });
        }
    </script>
</head>
<body>
    <header class="bg-dark text-white p-3">
        <div class="container d-flex justify-content-between">
            <h1>Available Properties</h1>
            <nav>
                <a href="index.php" class="text-white mx-2">Home</a>
                <a href="profile.php" class="text-white mx-2">Profile</a>
                <a href="logout.php" class="text-white mx-2">Logout</a>
            </nav>
        </div>
    </header>

    <div class="container mt-4">
        <h2>Find Your Ideal Property</h2>
        
        <div class="row mb-4">
            <div class="col-md-3">
                <label class="form-label">Property Type:</label>
                <select id="propertyType" class="form-select" onchange="filterProperties()">
                    <option value="all">All</option>
                    <option value="flat">Flat</option>
                    <option value="house">House</option>
                    <option value="2bhk">2BHK</option>
                    <option value="3bhk">3BHK</option>
                    <option value="land">Land</option>
                    <option value="agriculture">Agricultural Land</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Location:</label>
                <input type="text" id="location" class="form-control" onkeyup="filterProperties()" placeholder="Search by location...">
            </div>
            <div class="col-md-3">
                <label class="form-label">Min Price:</label>
                <input type="number" id="minPrice" class="form-control" onkeyup="filterProperties()" placeholder="₹">
            </div>
            <div class="col-md-3">
                <label class="form-label">Max Price:</label>
                <input type="number" id="maxPrice" class="form-control" onkeyup="filterProperties()" placeholder="₹">
            </div>
        </div>

        <div id="map" style="height: 400px; width: 100%; margin-bottom: 20px;"></div>

        <div class="row">
            <?php foreach ($properties as $property): ?>
                <div class="col-md-4 mb-4 property-item" data-type="<?= strtolower($property['property_type']); ?>" data-location="<?= strtolower($property['location']); ?>" data-price="<?= $property['price']; ?>">
                    <div class="card">
                        <?php 
                            $images = explode(',', $property['images']);
                            $firstImage = !empty($images[0]) ? trim($images[0]) : 'default.jpg';
                        ?>
                        <img src="<?= htmlspecialchars($firstImage); ?>" class="card-img-top" alt="<?= htmlspecialchars($property['details']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($property['details']); ?></h5>
                            <p><strong>Location:</strong> <?= htmlspecialchars($property['location']); ?></p>
                            <p><strong>Price:</strong> ₹<?= number_format($property['price']); ?></p>
                            <a href="property_details.php?id=<?= $property['id']; ?>" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
